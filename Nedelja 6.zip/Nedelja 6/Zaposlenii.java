
public class Zaposlenii {
	
	private int id;
	private String ime;
	private String prezime;
	private float plataPoSatu;
	private float ukupanBrojSati;
		
	public Zaposlenii(int id, String ime, String prezime, float plataPoSatu, float ukupanBrojSati) {
		super();
		this.setId(id);
		this.setIme(ime);
		this.setPrezime(prezime);
		this.setPlataPoSatu(plataPoSatu);
		this.setUkupanBrojSati(ukupanBrojSati);
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public float getPlataPoSatu() {
		return plataPoSatu;
	}
	public void setPlataPoSatu(float plataPoSatu) {
		this.plataPoSatu = plataPoSatu;
	}
	public float getUkupanBrojSati() {
		return ukupanBrojSati;
	}
	public void setUkupanBrojSati(float ukupanBrojSati) {
		this.ukupanBrojSati = ukupanBrojSati;
	}
	
	public float obracunajPlatu() {
		return 0;
	}
}
