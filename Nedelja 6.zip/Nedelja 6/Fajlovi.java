import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Fajlovi {

	public static void main(String[] args) throws FileNotFoundException {
		Scanner s = new Scanner(new File("src/Vozila.txt"));
		
		while (s.hasNext())
			System.out.println(s.nextLine());
		
		s.close();

	}

}
