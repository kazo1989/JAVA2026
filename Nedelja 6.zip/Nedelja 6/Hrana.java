import java.time.LocalDate;

public class Hrana extends Proizvod {
	
	private int brojKalorija;
	private LocalDate rokUpotrebe;
	
	public Hrana(String opis, String barkod, String zemljaProizvodnje, int godinaProizvodnje, float uvoznaCijenaProizvoda,
			int brojKalorija, LocalDate rokUpotrebe) {
		super(opis, barkod, zemljaProizvodnje, godinaProizvodnje, uvoznaCijenaProizvoda);
		this.setBrojKalorija(brojKalorija);
		this.setRokUpotrebe(rokUpotrebe);
	}
	
	public int getBrojKalorija() {
		return brojKalorija;
	}
	public void setBrojKalorija(int brojKalorija) {
		if(brojKalorija >= 0)
			this.brojKalorija = brojKalorija;
	}
	public LocalDate getRokUpotrebe() {
		return rokUpotrebe;
	}
	public void setRokUpotrebe(LocalDate rokUpotrebe) {
		this.rokUpotrebe = rokUpotrebe;
	}
	
	@Override
	public void dajUvoznuCijenu() {
		if (this.rokUpotrebe.isBefore(LocalDate.now().plusMonths(6)))
			this.setUvoznaCijenaProizvoda((float)(getUvoznaCijenaProizvoda() * 1.05));
		else
			this.setUvoznaCijenaProizvoda((float)(getUvoznaCijenaProizvoda() * 1.1));
	}
	
	@Override
	public String toString() {
		return "---Hrana---"
				+ "\nOpis: " + getOpis()
				+ "\nBroj kalorija: " + brojKalorija
				+ "\nRok Upotrebe: " + LocalDate.now().plusMonths(6)
				+ "\nBarkod: " + getBarkod()
				+ "\nZemlja porijekla: " + getZemljaProizvodnje()
				+ "\nGodina proizvodnje: " + getGodinaProizvodnje()
				+ "\nUvozna cijena prozivoda: " + getUvoznaCijenaProizvoda()
				+ "\n------------------------------------------";
	}

}
