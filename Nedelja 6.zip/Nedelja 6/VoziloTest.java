import java.util.ArrayList;

public class VoziloTest {

	public static void main(String[] args) {
		
		Automobil.setOsnovicaZaRegistraciju((float)1.5);
		
		// Automobil a = new Automobil("VW","Golf", 1496, 2007, 5, 5);
		// System.out.println(a.dajCijenuRegistracije());
		
		ArrayList <Vozilo> vozniPark = new ArrayList <Vozilo>();
		
		vozniPark.add(new Automobil("VW","Golf", 1496, 2007, 5, 5));
		vozniPark.add(new Automobil("BMW","M3", 3000, 2017, 5, 5));
		vozniPark.add(new Motocikl("Vespa","GTS", 310, 2026, 4000));
		vozniPark.add(new Kamion("Man","999", 6000, 2017, 10));
		
		for(Vozilo v : vozniPark)
			System.out.println(v);
		
		System.out.println();
		
		float ukupnaCijena = 0;
		
		for(Vozilo v : vozniPark)
			ukupnaCijena += v.dajCijenuRegistracije();
		
		System.out.printf("Ukupno za registraciju %.2f EUR.", ukupnaCijena);
		
	}

}
