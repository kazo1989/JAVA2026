
public class Proizvod {
	
	private String opis;
	private String barkod;
	private String zemljaProizvodnje;
	private int godinaProizvodnje;
	private float uvoznaCijenaProizvoda;
	
	public Proizvod(String opis, String barkod, String zemljaProizvodnje, int godinaProizvodnje, float uvoznaCijenaProizvoda) {
		this.setOpis(opis);
		this.setBarkod(barkod);
		this.setZemljaProizvodnje(zemljaProizvodnje);
		this.setGodinaProizvodnje(godinaProizvodnje);
		this.setUvoznaCijenaProizvoda(uvoznaCijenaProizvoda);
	}
	
	public String getOpis() {
		return opis;
	}
	public void setOpis(String opis) {
		this.opis = opis;
	}
	public String getBarkod() {
		return barkod;
	}
	public void setBarkod(String barkod) {
		this.barkod = barkod;
	}
	public String getZemljaProizvodnje() {
		return zemljaProizvodnje;
	}
	public void setZemljaProizvodnje(String zemljaProizvodnje) {
		this.zemljaProizvodnje = zemljaProizvodnje;
	}
	public int getGodinaProizvodnje() {
		return godinaProizvodnje;
	}
	public void setGodinaProizvodnje(int godinaProizvodnje) {
		this.godinaProizvodnje = godinaProizvodnje;
	}
	public float getUvoznaCijenaProizvoda() {
		return uvoznaCijenaProizvoda;
	}
	public void setUvoznaCijenaProizvoda(float uvoznaCijenaProizvoda) {
		this.uvoznaCijenaProizvoda = uvoznaCijenaProizvoda;
	}
	
	public void dajUvoznuCijenu() {
		this.setUvoznaCijenaProizvoda(0);
	}
	

}
