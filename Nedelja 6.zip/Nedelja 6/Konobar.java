
public class Konobar extends Zaposlenii {
	
	private int prekovremeniSati;
	
	public Konobar(int id, String ime, String prezime, float plataPoSatu, float ukupanBrojSati, int prekovremeniSati) {
		super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
		this.setPrekovremeniSati(prekovremeniSati);
	}

	public int getPrekovremeniSati() {
		return prekovremeniSati;
	}

	public void setPrekovremeniSati(int prekovremeniSati) {
		this.prekovremeniSati = prekovremeniSati;
	}
	
	@Override
	public float obracunajPlatu() {
		float plata;
		plata = 4 * this.getUkupanBrojSati() * this.getPlataPoSatu() + this.prekovremeniSati * ((float)(this.getPlataPoSatu() * 1.2));
		return plata;
	}
	

}