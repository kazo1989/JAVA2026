import java.time.LocalDate;
import java.util.ArrayList;

public class ProizvodTest {

	public static void main(String[] args) {
		
		ArrayList <Proizvod> proizvodi = new ArrayList <Proizvod>();
		
		proizvodi.add(new Garderoba("Majica", "523512514", "Kina", 2025, 5.5f, "Pamuk", "Zima"));
		proizvodi.add(new HemijskiProizvodi("Prasak", "123765321", "Francuska", 2023, 2.2f, 17.5f, false));
		proizvodi.add(new Hrana("Hleb", "61941420", "Crna Gora", 2026, 0.5f, 170, LocalDate.of(2026, 10, 29)));
		
		for(Proizvod p : proizvodi)
			System.out.println(p);
		
		for(Proizvod p : proizvodi)
			p.dajUvoznuCijenu();	
		
		System.out.println("*********************************************************************");
		
		for(Proizvod p : proizvodi)
			System.out.println(p);
		
	}

}
