import java.util.ArrayList;

public class Restoran {
	
	private String naziv;
	private String adresa;
	private int pib;
	private ArrayList<Zaposlenii> zaposlenii = new ArrayList<>();
	
	
	
	public Restoran(String naziv, String adresa, int pib, ArrayList<Zaposlenii> zaposlenii) {
		super();
		this.setNaziv(naziv);
		this.setAdresa(adresa);
		this.setPib(pib);
		this.setZaposlenii(zaposlenii);
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	public String getAdresa() {
		return adresa;
	}
	public void setAdresa(String adresa) {
		this.adresa = adresa;
	}
	public int getPib() {
		return pib;
	}
	public void setPib(int pib) {
		this.pib = pib;
	}
	public ArrayList<Zaposlenii> getZaposlenii() {
		return zaposlenii;
	}
	public void setZaposlenii(ArrayList<Zaposlenii> zaposlenii) {
		this.zaposlenii = zaposlenii;
	}
	
	public void dodajZaposlenog(Zaposlenii z) {
		zaposlenii.add(z);
	}
	
	public void ukloniZaposlenogPoId(int id) {
	    zaposlenii.removeIf(Zaposlenii -> Zaposlenii.getId() == id);
	}

	public void nadjiZaposlenog(int id) {
		for (Zaposlenii z : this.zaposlenii)
			if(z.getId() == id)
				System.out.println(z.getIme());
	}
	
}
