import java.time.LocalDate;

public class Kamion extends Vozilo {
	
private int nosivost;
	
	public Kamion() {
		this(null, null, 0, 1945, 0);
	}

	public Kamion(String marka, String model, int kubikaza, int godiste, int nosivost) {
		super(marka, model, kubikaza, godiste);
		this.setNosivost(nosivost);
	}

	public float getNosivost() {
		return nosivost;
	}

	public void setNosivost(int nosivost) {
		if (nosivost >= 0)
			this.nosivost = nosivost;
	}

	@Override
	public String toString() {
		return "Kamion [nosivost=" + nosivost + ", marka=" + getMarka() + ", model=" + getModel()
				+ ", kubikaza=" + getKubikaza() + ", godiste=" + getGodiste() + "]";
	}
	
	@Override
	public float dajCijenuRegistracije() {
		float cijena;
		cijena = ((float)this.getKubikaza() / 10 + (LocalDate.now().getYear() - this.getGodiste()) * 10) * Vozilo.getOsnovicaZaRegistraciju() + 30 * this.getNosivost();
		return cijena;
	}

}
