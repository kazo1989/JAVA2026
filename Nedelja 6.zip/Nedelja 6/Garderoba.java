
public class Garderoba extends Proizvod {
	
	private String materijalProizvodnje;
	private String sezona;
	
	public Garderoba(String opis, String barkod, String zemljaProizvodnje, int godinaProizvodnje,
			float uvoznaCijenaProizvoda, String materijalProizvodnje, String sezona) {
		super(opis, barkod, zemljaProizvodnje, godinaProizvodnje, uvoznaCijenaProizvoda);
		this.setMaterijalProizvodnje(materijalProizvodnje);
		this.setSezona(sezona);
	}
	
	public String getMaterijalProizvodnje() {
		return materijalProizvodnje;
	}
	public void setMaterijalProizvodnje(String materijalProizvodnje) {
		this.materijalProizvodnje = materijalProizvodnje;
	}
	public String getSezona() {
		return sezona;
	}
	public void setSezona(String sezona) {
		this.sezona = sezona;
	}
	
	@Override
	public void dajUvoznuCijenu() {
		this.setUvoznaCijenaProizvoda((float)(getUvoznaCijenaProizvoda() * 1.05));
	}

	@Override
	public String toString() {
		return "---Garderoba---"
				+ "\nOpis: " + getOpis()
				+ "\nMaterijal proizvodnje: " + materijalProizvodnje
				+ "\nSezona: " + sezona
				+ "\nBarkod: " + getBarkod()
				+ "\nZemlja porijekla: " + getZemljaProizvodnje()
				+ "\nGodina proizvodnje: " + getGodinaProizvodnje()
				+ "\nUvozna cijena prozivoda: " + getUvoznaCijenaProizvoda()
				+ "\n------------------------------------------";
	}

	
	
	
}
