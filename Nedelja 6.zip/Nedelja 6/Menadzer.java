
public class Menadzer extends Zaposlenii {
	
	private float bonus;
	
	public Menadzer(int id, String ime, String prezime, float plataPoSatu, float ukupanBrojSati, float bonus) {
		super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
		this.setBonus(bonus);
	}

	public float getBonus() {
		return bonus;
	}

	public void setBonus(float bonus) {
		this.bonus = bonus;
	}
	
	@Override
	public float obracunajPlatu() {
		float plata;
		plata = 1300 + 4 * this.getUkupanBrojSati() * this.getPlataPoSatu() + this.bonus;
		return plata;
	}

}
