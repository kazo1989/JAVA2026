
public class Kuvar extends Zaposlenii {

	public Kuvar(int id, String ime, String prezime, float plataPoSatu, float ukupanBrojSati) {
		super(id, ime, prezime, plataPoSatu, ukupanBrojSati);
	}
	
	@Override
	public float obracunajPlatu() {
		float plata;
		plata = 1500 + 4 * this.getUkupanBrojSati() * this.getPlataPoSatu();
		return plata;
	}
	
}
