
public class HemijskiProizvodi extends Proizvod {
	
	public float temperaturaSkladistenja;
	private boolean zapaljivo;
	
	public HemijskiProizvodi(String opis, String barkod, String zemljaProizvodnje, int godinaProizvodnje,
			float uvoznaCijenaProizvoda, float temperaturaSkladistenja, boolean zapaljivo) {
		super(opis, barkod, zemljaProizvodnje, godinaProizvodnje, uvoznaCijenaProizvoda);
		this.setTemperaturaSkladistenja(temperaturaSkladistenja);
		this.setZapaljivo(zapaljivo);
	}

	public float getTemperaturaSkladistenja() {
		return temperaturaSkladistenja;
	}

	public void setTemperaturaSkladistenja(float temperaturaSkladistenja) {
		this.temperaturaSkladistenja = temperaturaSkladistenja;
	}

	public boolean isZapaljivo() {
		return zapaljivo;
	}

	public void setZapaljivo(boolean zapaljivo) {
		this.zapaljivo = zapaljivo;
	}
	
	@Override
	public void dajUvoznuCijenu() {
		if (this.zapaljivo)
			this.setUvoznaCijenaProizvoda((float)(getUvoznaCijenaProizvoda() * 1.125));
		else
			this.setUvoznaCijenaProizvoda((float)(getUvoznaCijenaProizvoda() * 1.1));
	}
	
	@Override
	public String toString() {
		return "---Hemijski proizvodi---"
				+ "\nOpis: " + getOpis()
				+ "\nTemperatura skladistenja: " + temperaturaSkladistenja
				+ "\nZapaljivo: " + (zapaljivo?"Da":"Ne")
				+ "\nBarkod: " + getBarkod()
				+ "\nZemlja porijekla: " + getZemljaProizvodnje()
				+ "\nGodina proizvodnje: " + getGodinaProizvodnje()
				+ "\nUvozna cijena prozivoda: " + getUvoznaCijenaProizvoda()
				+ "\n------------------------------------------";
	}

}
