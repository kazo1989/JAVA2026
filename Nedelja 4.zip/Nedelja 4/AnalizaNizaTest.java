import java.util.Scanner;

public class AnalizaNizaTest {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("Unesite broj elemenata niza: ");
		int N = sc.nextInt();

		int[] niz = new int[N];

		for (int i = 0; i < niz.length; i++) {
			System.out.printf("Unesite %d. element niza: ", i + 1);
			niz[i] = sc.nextInt();
		}

		AnalizaNiza niz2 = new AnalizaNiza(niz);

		double prosjek = AnalizaNiza.nadjiParniPozitivniProsjek(niz2.getNiz());

		if (prosjek == 0)
			System.out.println("U nizu nema pozitivnih parnih brojeva.");
		else
			System.out.println("Prosjecna vrijednost pozitivnih parnih brojeva je " + prosjek);

		sc.close();

	}

}