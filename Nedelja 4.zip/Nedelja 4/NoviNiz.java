import java.util.Random;
import java.util.Scanner;

public class NoviNiz {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Random r = new Random();

		System.out.print("Unesite duzinu niza: ");
		int N = sc.nextInt();

		int[] niz = new int[N];

		for (int i = 0; i < niz.length; i++)
			niz[i] = r.nextInt(100) + 1;

		System.out.println("Originalni niz:");
		for (int element : niz)
			System.out.print(element + " ");
		System.out.println();

		double[] izmijenjeni = new double[N];

		for (int i = 0; i < niz.length; i++) {
			if (niz[i] % 2 == 0)
				izmijenjeni[i] = -1 * niz[i];
			else
				izmijenjeni[i] = 1.0 / niz[i];
		}

		System.out.println("Izmijenjeni niz:");
		for (double element : izmijenjeni)
			if (element % 2 == 0)
				System.out.print((int)element + " ");
			else
				System.out.printf("%.3f ", element);
		System.out.println();

		sc.close();

	}

}