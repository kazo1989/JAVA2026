public class AnalizaNiza {

	private int[] niz;

	public AnalizaNiza(int[] niz) {
		this.niz = niz;
	}

	public int[] getNiz() {
		return niz;
	}

	public void setNiz(int[] niz) {
		this.niz = niz;
	}

	public static double nadjiParniPozitivniProsjek(int[] niz) {

		int zbir = 0;
		int brojac = 0;

		for (int element : niz) {
			if (element > 0 && element % 2 == 0) {
				zbir += element;
				brojac++;
			}
		}

		if (brojac == 0)
			return 0;
		else
			return (double) zbir / brojac;

	}

}