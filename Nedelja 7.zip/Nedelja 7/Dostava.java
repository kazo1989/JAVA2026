import java.util.ArrayList;
import java.util.Random;

public class Dostava {

	public static void main(String[] args) {
		ArrayList<Vozilo> vozila = new  ArrayList<Vozilo>();
		vozila.add(new Bicikl(1, 10.0));
		vozila.add(new Bicikl(2, 12.0));
		vozila.add(new Motor(3, 52.0));
		vozila.add(new Motor(4, 75.0));
		vozila.add(new Automobil(5, 110.0));
		vozila.add(new Automobil(6, 150.0));
		
		double udaljenost;
		
		for(Vozilo v : vozila) {
			udaljenost = 10.0;
			udaljenost += new Random().nextDouble();
			v.info();
			System.out.println("Vrijeme dostave: "+ v.izracunajVrijemeDostave(udaljenost));
			
			if(v instanceof Ekonomican) {
				Ekonomican e = (Ekonomican)v;
				System.out.println("Vozilo je ekonomicno, a potrosnja je: " + e.potrosnjaPoKm());
			}else {
				System.out.println("Vozilo je automobil.");
			}
		}

	}

}
