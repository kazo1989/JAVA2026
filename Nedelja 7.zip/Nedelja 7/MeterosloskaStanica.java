
public class MeterosloskaStanica {

	public static void main(String[] args) {
		
		String s = "c123s015g028t068r002p017h53b10020*CS";
		System.out.println(dajPodatke(s));

	}
	
	public static String dajPodatke(String s) {
		String izl;
		
		// Obradi temperaturu
		int iT = s.indexOf("t");
		// System.out.println(s.substring(iT+1, iT+4));
		float tt = Float.parseFloat(s.substring(iT+1, iT+4));
		// System.out.println(tt);
		// System.out.println((tt - 32) * 5/9);
		float temp = (tt - 32) * 5/9;
		
		// Obradi vlaznost
		int iH = s.indexOf("h");
		// System.out.println(s.substring(iH+1, iH+3));
		float vlaznost = Float.parseFloat(s.substring(iH+1, iH+3));
		
		int iB = s.indexOf("b");
		// System.out.println(s.substring(iB+1, iB+6));
		float pritisak = Float.parseFloat(s.substring(iB+1, iB+6))*0.1f;
		
		izl	= String.format("{'temp': %.1f, 'vlaznost': %.1f%%, 'pritisak': %.1f}", temp, vlaznost, pritisak);	
		
		return izl;
	}

}
