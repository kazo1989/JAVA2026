import java.util.Scanner;

public class TrougaoZvezdice {

	public static void main(String[] args) {
		int N;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Unesi N: ");
		N = sc.nextInt();
		
		while(N <= 0) {
			System.out.print("Unesi N ponovo, N je <= 0: ");
			N = sc.nextInt();
		}
		
		/*
		for(int i = 1; i <= N; i++) {
			for(int j = N; j >= i; j--)
				System.out.print("*");
			System.out.print("\n");
		}
		*/
		
		
		String s = "*";
		
		for(int i = 1; i <= N; i++) {
			System.out.println(s);
			s += "*";
		}

		
		sc.close();

	}

}
