
public class Bicikl extends Vozilo implements Ekonomican {

  public Bicikl(int id, double maxBrzina) {
    super(id, maxBrzina);
  }

  @Override
  public double izracunajVrijemeDostave(double udaljenostKm) {
    return udaljenostKm / this.getMaxBrzina();
  }

  @Override
  public double potrosnjaPoKm() {
    return 0;
  }
}