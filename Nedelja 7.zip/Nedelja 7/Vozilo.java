public abstract class Vozilo {
	
  private int id;
  private double maxBrzina;

  public Vozilo(int id, double maxBrzina) {
    this.setId(id);
    this.setMaxBrzina(maxBrzina);
  }

  public int getId() { return id; }
  public void setId(int id) {
    if (id > 0)
      this.id = id;
  }

  public double getMaxBrzina() { return maxBrzina; }
  public void setMaxBrzina(double maxBrzina) {
    if (maxBrzina > 0)
      this.maxBrzina = maxBrzina;
  }

  public void info() {
    System.out.println("Vozilo [id=" + id + ", maxBrzina=" + maxBrzina + "]");
  }

  public abstract double izracunajVrijemeDostave(double udaljenostKm);
}