// Za unijeti string, da li je broker u plus ili minus: ulaz S50 S40 B50 B100 --> izlaz -60

import java.util.Scanner;

public class Broker {

    public static int izracunajBilans(String trgovine) {
        trgovine = trgovine + " ";
        int bilans = 0;
        int broj = 0;
        char tip = ' ';

        for (int i = 0; i < trgovine.length(); i++) {
            char c = trgovine.charAt(i);

            if (c == 'S' || c == 'B') {
                tip = c;
                broj = 0;
            } else if (c >= '0' && c <= '9') {
                broj = broj * 10 + (c - '0');
            } else {
                if (tip == 'S') {
                    bilans = bilans + broj;
                } else if (tip == 'B') {
                    bilans = bilans - broj;
                }
                tip = ' ';
                broj = 0;
            }
        }

        return bilans;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Unesite transakcije: ");
        String trgovine = sc.nextLine();

        int bilans = izracunajBilans(trgovine);
        System.out.println("Bilans: " + bilans);

        sc.close();
    }
}