// Da li je rijec palindrom: ana voli milovana jeste jer je od iza isto

import java.util.Scanner;

public class Palindrom {

    public static boolean jePalindrom(String tekst) {
        String bezRazmaka = tekst.replace(" ", "");

        StringBuilder sb = new StringBuilder(bezRazmaka);
        sb.reverse();

        return bezRazmaka.equalsIgnoreCase(sb.toString());
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Unesite tekst: ");
        String tekst = sc.nextLine();

        if (jePalindrom(tekst)) {
            System.out.println("Palindrom je");
        } else {
            System.out.println("Nije palindrom");
        }

        sc.close();
    }
}