// Koliko rijeci ima u recenici

import java.util.Scanner;

public class OdvajanjePraznina {
	
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Unesite rečenicu: ");
        String recenica = sc.nextLine().trim();

        String[] rijeci = recenica.split(" ");

        System.out.println("Broj riječi: " + rijeci.length);
        
        sc.close();
    }
}